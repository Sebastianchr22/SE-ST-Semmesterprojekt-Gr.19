package logic;

import java.util.ArrayList;
import acq.IListBuilder;

public class Inventory implements IListBuilder {

    ArrayList<Item> Inventory = new ArrayList();

    private int totalSize = 0;
    private int totalWeight = 0;
    private int goldItems = 0;
    private int silverItems = 0;
    private int Outfit = 0;
    private int wig = 0;
    private int shoes = 0;
    private int makeup = 0;
    private int weddingringvar = 0;
    private int Adidas = 0;
    private Item weddingring = new Item(0, "Wedding Ring", "Your wedding ring given to you by your ex- boyfriend", "Wedding", 3);
    private Item carkeys = new Item(90, "Car keys", "A bundle of keys", "Key", 0);


    /**
     * Non-parameter constructor that adds the item weddingring to the inventory
     */
    Inventory() {

        //Adds all starting items to the inventory:
        Inventory.add(weddingring);
    }

    /**
     * Method that add an item to the Inventory
     * 
     * Takes the parameter item
     * then adds the item to the ArrayList Inventory
     * 
     * @param item 
     */
    @Override
    public void addToList(Item item) {
        Inventory.add(item);
    }

    /**
     * Method that removes an item from the inventory
     * 
     * Takes the parameter item
     * then removes the item from the ArrayList Inventory
     * 
     * @param item 
     */
    @Override
    public void removeFromList(Item item) {
        Inventory.remove(item);
    }

    /**
     * Method for counting the amount of items in the Inventory
     * 
     * this method uses an for each loop to count the amount of items in the Inventory
     * 
     * @return an integer of amount of items in the Inventory 
     */
    int listLenght() {
        int count = 0;
        for (Item item : Inventory) {
            count++;
        }
        return count;
    }

    /**
     * Method for counting amount of items in the inventory, how many items of each category there is and the totalWeight
     * 
     * First the method resets the class variables
     * then it uses a for each loop to run through each item in the inventory
     * then each item goes through a switch case, which uses the method getCat() from the Item class
     * to find the category of each item and then adds 1 to category variables if it fits in any of the category cases
     * Still in the loop after the case, it add the value of each of the items getSize()(our size unit) to the totalSize variable
     * After the loop the method makes a totalWeight variable taking the totalSize unit * 5
     * 
     */
    void countItems() {
        //Setting default values to avoid error counting:
        totalSize = 0;
        totalWeight = 0;
        goldItems = 0;
        silverItems = 0;
        Outfit = 0;
        wig = 0;
        shoes = 0;
        makeup = 0;
        weddingringvar = 0;
        Adidas = 0;
        for (Item item : Inventory) {
            switch (item.getCat()) {
                case "Gold":
                    goldItems++;
                    break;
                case "Silver":
                    silverItems++;
                    break;
                case "Outfit":
                    Outfit++;
                    break;
                case "Wig":
                    wig++;
                    break;
                case "Shoes":
                    shoes++;
                    break;
                case "Makeup":
                    makeup++;
                    break;
                case "Adidas":
                    Adidas++;
                    break;
                case "Wedding":
                    weddingringvar = 1;
                    break;
            }
            totalSize += item.getSize();
        }
        totalWeight = totalSize * 5;
    }

    /**
     * Boolean method for checking if there is enough capacity to hold an extra item
     * 
     * Takes the parameter item
     * then checks (the size of the item * 5) + the totalWeight we have in the inventory
     * if it is equal to or lower than 1000 the method returns a true boolean value
     * or else the method returns a false boolean value
     * 
     * @param item
     * @return boolean value
     */
    boolean checkCapacity(Item item) {
        countItems();
        if (totalWeight + item.getSize() * 5 <= 1000) {
            //Under capasity:
            return true;
        } else {
            //Over capasity:
            System.out.println("You cannot carry any more.");
            return false;
        }
    }

    /**
     * Accessor method for getting the totalWeight
     * 
     * First the method calls the countItems method so that it knows the what the current totalWeight is
     * then it returns the totalWeight as an integer
     * 
     * @return integer of totalWeight
     */
    int getTotalWeight() {
        countItems();
        return this.totalWeight;
    }

    /**
     * ToString method that returns a String representation of current Weight out of the maximum Weight
     * 
     * The method calls the countItems method so that it knows the what the current totalWeight is
     * then returns a String
     * 
     * @return String
     */
    String weightToString() {
        countItems();
        return "Capacity: " + totalWeight + "/1000g";
    }

    /**
     * Method for returning amount of items with a specific category we have in the inventory
     * 
     * First calls the countItems() method, to know how many items of each category there is. 
     * Then it takes the String parameter in the switch case to match one of the categories we a searching for
     * If the parameter match any of the categories, it returns an integer value of how many items with that category we have in our inventory
     * else if the parameter doesn't match any it will just return a 0;
     * 
     * @param type: String of the category that is being checked for
     * @return 
     */
    int getSpecific(String type) {
        countItems();
        switch (type) {
            case "Gold":
                return this.goldItems;
            case "Silver":
                return this.silverItems;
            case "Outfit":
                return this.Outfit;
            case "Wig":
                return this.wig;
            case "Shoes":
                return this.shoes;
            case "Makeup":
                return this.makeup;
            case "Wedding":
                return this.weddingringvar;
            case "Adidas":
                return this.Adidas;
            default:
                return 0;
        }
    }

    /**
     * Accessor method for getting the item: wedding ring
     * 
     * @return the item: wedding ring
     */
    public Item getWeddingRing() {
        return this.weddingring;
    }
    
    /**
     * Accessor method for getting the item car keys
     * 
     * @return the item: car keys
     */
    public Item getCarKeys(){
        return this.carkeys;
    }

    /**
     * Method for printing item names and weight to a string
     * 
     * Uses a for each loop to print item names and weight from the item in the inventory
     * 
     */
    public void showList() {
        int counter = 0;
        System.out.println("Item Name:                         Weight:");
        System.out.println("");
        for (Item item : Inventory) {
            System.out.println(counter + ". " + item.getValues() + "     |  " + item.getSize() * 5 + "g");
            counter++;
        }
        System.out.println("");
        System.out.println(weightToString());
    }
}
