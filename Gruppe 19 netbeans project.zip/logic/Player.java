package logic;

import acq.ILogic;
import java.util.ArrayList;

public class Player
{

    private static ILogic logic;

    private int Experience = 0;
    private int Enhancements = 0;
    private int Moves = 12;
    private double moneySaved = 0;
    private int currentHunger = 100;
    private int daysLeft = 20;

    private final Item weddingring = new Item(0, "Wedding Ring", "Your wedding ring given to you by your ex- boyfriend", "Wedding", 3);

    /**
     * Empty constructor, creates the default player, used each time you start a
     * new game.
     */
    Player()
    {
        int Experience = 0;
        int Enhancements = 0;
        int Moves = 12;
        double moneySaved = 0;
        int currentHunger = 100;
        int daysLeft = 20;
    }

    /**
     * This contructor needs all the different parameters, as it is made to
     * create a player with a set of predefined parameters, for example when you
     * load a game, this is used to recreate your player.
     *
     * @param exp
     * @param enh
     * @param moves
     * @param money
     * @param hunger
     * @param days
     * @param list
     * @param logic
     */
    Player(int exp, int enh, int moves, double money, int hunger, int days, ArrayList<String> list, ILogic logic)
    {
        this.Enhancements = enh;
        this.Experience = exp;
        this.moneySaved = money;
        this.Moves = moves;
        this.currentHunger = hunger;
        this.daysLeft = days;

        for (String val : list)
        {
            Item item = containsItem(val, logic.getItemList());
            if (!val.equals("Wedding Ring"))
            {
                logic.addToInventory(item);
                logic.removeFromItemList(item);
            }
            else
            {
                logic.addToInventory(weddingring);
            }
        }
    }

    /**
     * Gets the weddingring
     *
     * @return weddingring
     */
    Item getWeddingRing()
    {
        return this.weddingring;
    }

    /**
     * Adds i amount of enhancements.
     *
     * @param i
     */
    void addEnhancements(int i)
    {
        this.Enhancements += i;
    }

    /**
     * Adds i amount of hunger.
     *
     * @param i
     */
    void addHunger(int i)
    {
        this.currentHunger += i;
    }

    /**
     * Adds i amount of days left.
     *
     * @param i
     */
    void addDaysLeft(int i)
    {
        this.daysLeft += i;
    }

    /**
     * Adds i amount of experience.
     *
     * @param i
     */
    void addExperience(int i)
    {
        this.Experience += i;
    }

    /**
     * Adds i amount of money.
     *
     * @param i
     */
    void addMoney(double i)
    {
        this.moneySaved += i;
    }

    /**
     * Adds i amount of moves.
     *
     * @param i
     */
    void addMoves(int i)
    {
        this.Moves += i;
    }

    /**
     * Removes i amount of money.
     *
     * @param i
     */
    void removeMoney(double i)
    {
        this.moneySaved -= i;
    }

    /**
     * Sets this.Experience to Experience.
     *
     * @param Experience
     */
    void setExperience(int Experience)
    {
        this.Experience = Experience;
    }

    /**
     * Sets this.Enhancements to Enhancements.
     *
     * @param Enhancements
     */
    void setEnhancements(int Enhancements)
    {
        this.Enhancements = Enhancements;
    }

    /**
     * Set this.Moves to Moves.
     *
     * @param Moves
     */
    void setMoves(int Moves)
    {
        this.Moves = Moves;
    }

    /**
     * Sets this.moneySaved to moneySaved.
     *
     * @param moneySaved
     */
    void setMoneySaved(double moneySaved)
    {
        this.moneySaved = moneySaved;
    }

    /**
     * Sets this.currentHunger to currentHunger.
     *
     * @param currentHunger
     */
    void setCurrentHunger(int currentHunger)
    {
        this.currentHunger = currentHunger;
    }

    /**
     * Sets this.daysLeft to daysLeft.
     *
     * @param daysLeft
     */
    void setDaysLeft(int daysLeft)
    {
        this.daysLeft = daysLeft;
    }

    /**
     * Returns the money you have saved.
     *
     * @return moneySaved
     */
    double getMoneySaved()
    {
        return Math.round(this.moneySaved * 100.0) / 100.0;
    }

    /**
     * Returns the amount of enhancements you have.
     *
     * @return Enhancements
     */
    int getEnhancements()
    {
        return this.Enhancements;
    }

    /**
     * Returns the amount of experience you have.
     *
     * @return Experience
     */
    int getExperience()
    {
        return this.Experience;
    }

    /**
     * Returns the amount of currentHunger you have.
     *
     * @return currentHunger
     */
    int getHunger()
    {
        return this.currentHunger;
    }

    /**
     * Returns the amount of days you have left.
     *
     * @return daysLeft
     */
    int getDaysLeft()
    {
        return this.daysLeft;
    }

    /**
     * Returns the amount of moves you have left.
     *
     * @return Moves
     */
    int getMoves()
    {
        return this.Moves;
    }

    /**
     * Returns a string with the amount of hunger out of a 100.
     *
     * @return
     */
    String getShortHunger()
    {
        return this.currentHunger + "/100";
    }

    /**
     * Resets the moves to the standard, 12.
     */
    void resetMoves()
    {
        this.Moves = 12;
    }

    /**
     * Removes i number of days left.
     *
     * @param i
     */
    void removeDaysLeft(int i)
    {
        this.daysLeft -= i;
    }

    /**
     * Removes i number of moves.
     *
     * @param i
     */
    void removeMoves(int i)
    {
        this.Moves -= i;
    }

    /**
     * Removes i number of hunger.
     *
     * @param i
     */
    void removeHunger(int i)
    {
        this.currentHunger -= i;
    }

    /**
     * This method goes through the itemlist to find an item.
     *
     * @param name
     * @param itemlist
     * @return
     */
    public Item containsItem(String name, ArrayList<Item> itemlist)
    {
        for (Item item : itemlist)
        {
            if (item.getName().equals(name))
            {
                return item;
            }
        }
        return null;
    }
}
