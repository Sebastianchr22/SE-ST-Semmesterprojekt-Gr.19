package logic;

import acq.ILogic;
import acq.IPreference;
import acq.IRegular;

/**
 * RegularPlayerMatch class checks and matches a player with a regular, granted
 * all the condition are meet.
 *
 */

public class RegularPlayerMatch {

    private ILogic logic = LogicFacade.getInstance();
    private Inventory inv;

    Chance chance = new Chance();

    /**
     * <p>
     * The Match method contains a boolean as return type and acquires its
     * parameter from IPreference. The method begins by settings a boolean
     * called res to false. The method then uses a switch statement containing a
     * name of a regular to check if that certain regulars preference is equal
     * to what the player has in inventory. if the regulars preference is equal
     * to the items you have in your inventory then res returns true.
     *
     * @return res returns true for all the cases that match your inventory.
     * </p>
     */
    public boolean Match(IPreference preference) {

        boolean res = false;
        switch (preference.getName()) {
            case "Gold":
                if (preference.getAmount() <= inv.getSpecific("Gold")) {
                    res = true;
                }
                break;
            case "Silver":
                if (preference.getAmount() <= inv.getSpecific("Silver")) {
                    res = true;
                }
            case "Outfit":
                if (preference.getAmount() <= inv.getSpecific("Outfit")) {
                    res = true;
                }
                break;
            case "Wig":
                if (preference.getAmount() <= inv.getSpecific("Wig")) {
                    res = true;
                }
                break;
            case "Shoes":
                if (preference.getAmount() <= inv.getSpecific("Shoes")) {
                    res = true;
                }
                break;
            case "Makeup":
                if (preference.getAmount() <= inv.getSpecific("Makeup")) {
                    res = true;
                }
                break;
            case "Adidas":
                if (preference.getAmount() <= inv.getSpecific("Adidas")) {
                    res = true;
                }
                break;
            case "Wedding":
                if (preference.getAmount() <= inv.getSpecific("Wedding")) {
                    res = true;
                }
                break;
        }
        return res;
    }

    /**
     * <p>
     * The method RegularPlayerMatch start by creating a empty String called
     * val, and then getting players inventory from the ILogic Facade. Then
     * there is a if-else with a condition stating that if the player matches
     * with a regular based on preference0 and preference1. As long as that
     * condition is true the string val is displayed and you will then have 60%
     * chance of being invited to a hotel/motel. If you are invited to
     * hotel/motel the if-statement will return the string val and based on if
     * you have been invited to either a hotel or a motel, a method in the class
     * HotelMotelInvite, checks how much money the regular who invited you has
     * and based on that you will either go to a hotel or motel. if u are
     * unlucky and you dont get invited anywhere the regulars name will be
     * displayed along with a string letting you know that the regular didnt
     * invite you anywhere.
     * </p>
     *
     * <p>
     * @param regular comes from the interface IRegular, it contains the all the
     * information about a regular.
     * @return based on the method RegularPlayerMatch, val will return a string
     * which contains information about if you have a match or not.
     * </p>
     *
     * <p>
     * The other option is that the player and the regular are not a match based
     * on preference and then a string will display telling you, you are not a
     * match, and the 3 methods setRegularInRoom, setPrivateRoomCommand and
     * setPRoomInvite will set to be false or null.
     * </p>
     */
    public String RegularPlayerMatch(IRegular regular) {
        String val = "";
        inv = logic.getInv();
        if (Match(regular.getPreference0()) && Match(regular.getPreference1())) {
            val = "The two of you are a match!";
            if (chance.ChanceCalc(60, 100)) {
                //Invite to hotel / motel:
                HotelMotelInvite invite = new HotelMotelInvite();
                return val + "\n" + invite.HotelMotelInvite(regular);
            } else {
                return logic.getRegularInRoom().getName() + " did not invite anywhere, and just left.";
            }
        } else {
            val = "You two are not a match..";
            logic.setRegularInRoom(null);
            logic.setPrivateRoomCommand(null);
            logic.setPRoomInvite(false);
        }
        return val;

    }
}
