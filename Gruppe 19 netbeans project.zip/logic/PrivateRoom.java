package logic;

import acq.ILogic;
import acq.IRegular;

/**
 * The private-room class contains all the functionality and calculations
 * performed for private-room.
 *
 */
public class PrivateRoom {

    private ILogic logic;

    /**
     * <p>
     * @param bonus is a double parameter in the method tipsGained.
     * @param i is a double parameter in the method tipsGained.
     * @return Returns the random* the percentage, rounded off with two digits
     * after the comma.
     * </p>
     */
    public double tipsGained(double bonus, double i) {
        double percentageBonusTip = 1 + logic.getPlayer().getEnhancements() * 0.05;//Calculates a percentage of bonus based on improvements
        double tips = 5.0 + Math.random() * 30.0;//Calculates a random number between 5 to 30
        return Math.round((percentageBonusTip * tips + bonus + i) * 100.0) / 100.0;
    }

    /**
     * <p>
     * @param regular
     * @return returns if player and a regular is a match.
     * </p>
     */
    public String Match(IRegular regular) {
        //Boolean method to check if a regular and a player is a match:
        RegularPlayerMatch match = new RegularPlayerMatch();
        return match.RegularPlayerMatch(regular);
    }

    /**
     * <p>
     * privateRoom method creates a empty string called val, and sets the method
     * setInPRoom to true. In the if-statement, the method getRegularInRoom,
     * finds out which regular is in the room, and gets his age If his age is
     * less then 21, another if-statment will runs ChanceCalc, with a 50% chance
     * of getting caught by the police. If you get caught val will display 3
     * strings and the player will lose money, gain no exp and the player will
     * be removed from private-room. If you don't get caught a string will
     * return telling you that police didn't notice you, and you will gain extra
     * exp and tips.
     * </p>
     *
     * <p>
     * If the regular you are dancing for isn't a minor, and there hasnt been a
     * police raid, you will gain 100 tips and 3 exp.
     *
     * @return val returns a value based on the if-statement.
     * </p>
     */
    public String PrivateRoom() {
        String val = "";
        logic = LogicFacade.getInstance();
        logic.setInPRoom(true);
        //If the regular is a minor, a raid might happen
        Chance chance = new Chance();
        if (logic.getRegularInRoom().getAge() < 21) {
            //Chance of police raid 50%:
            if (chance.ChanceCalc(50, 100)) {
                //Returned true:
                val += "A police raid just happened and you just got busted dancing for a minor.";
                val += "The police hand you a $500 fine, and you are being held at the police station over night.";
                val += "You gained some experience from the raid, and from your arrest.";
                logic.getPlayer().removeMoney(500);
                logic.getPlayer().addExperience(0);
                logic.setRegularInRoom(null);
                logic.setPrivateRoomCommand(null);
                logic.setPRoomInvite(false);
            } else {
                //Returned false:
                val += "A police raid just happened, thankfully the police did not notice that you were dancing for a minor.";
                val += "You gained some experience from that raid.";
                logic.getPlayer().addExperience(3);
                val += pRoomTips(250);
                logic.setRegularInRoom(null);
                logic.setPrivateRoomCommand(null);
                logic.setPRoomInvite(false);
            }
            logic.setInPRoom(false);
        } else {
            //No razzia:
            //No minor:
            val += pRoomTips(100);
            val += Match(logic.getRegularInRoom());
            logic.getPlayer().addExperience(3);
        }
        return val;
    }

    /**
     * <p>
     * @param bonus this is a extra bonus that will be added to the amount you
     * have already earned in the privateRoom-method.
     * @return returns the amount of money you have made from dancing in
     * private-room through a string.
     * </p>
     */
    public String pRoomTips(int bonus) {
        double amount = Math.round((tipsGained(bonus, logic.getPlayer().getEnhancements() * 6.5 + 350 + bonus)) * 100.0) / 100.0;
        logic.getPlayer().addMoney(amount);
        return "You gained $" + amount + " from dancing.";
    }
}
