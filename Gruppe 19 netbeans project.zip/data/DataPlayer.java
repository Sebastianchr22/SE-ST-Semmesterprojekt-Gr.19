package data;

import java.util.ArrayList;

public class DataPlayer implements acq.IPlayer {

    private int Experience = 0;
    private int Enhancements = 0;
    private int Moves = 12;
    private double moneySaved = 10;
    private int currentHunger = 100;
    private int daysLeft = 20;
    
    private ArrayList<String> inv = new ArrayList();
    
    DataPlayer(){}

    /**
    *The DataPlayer class, exists with the sole purpose til migrate data from the data layer to the logic layer. So the only time we use this is when we load and save games.
    *
    *@param exp
    *@param enh
    *@param moves
    *@param money
    *@param hunger
    *@param days
    *@param list
    */
    DataPlayer(int exp, int enh, int moves, double money, int hunger, int days, ArrayList<String> list) {
        this.Enhancements = enh;
        this.Experience = exp;
        this.moneySaved = money;
        this.Moves = moves;
        this.currentHunger = hunger;
        this.daysLeft = days;
        this.inv = list;
    }

    /**
    *This method is implemented so we can get the data through our interface.
    *
    *@return moneySaved
    */
    @Override
    public double getMoneySaved() {
        return this.moneySaved;
    }

    /**
    *This method is implemented so we can get the data through our interface.
    *
    *@return Enhancements
    */
    @Override
    public int getEnhancements() {
        return this.Enhancements;
    }
    
    /**
    *This method is implemented so we can get the data through our interface.
    *
    *@return Experience
    */
    @Override
    public int getExperience() {
        return this.Experience;
    }
    
    /**
    *This method is implemented so we can get the data through our interface.
    *
    *@return currentHunger
    */
    @Override
    public int getHunger() {
        return this.currentHunger;
    }
    
    /**
    *This method is implemented so we can get the data through our interface.
    *
    *@return daysLeft
    */
    @Override
    public int getDaysLeft() {
        return this.daysLeft;
    }
    
    /**
    *This method is implemented so we can get the data through our interface.
    *
    *@return Moves
    */
    @Override
    public int getMoves() {
        return this.Moves;
    }
    
    /**
    *This method is implemented so we can get the data through our interface.
    *
    *@return inv
    */
    @Override
    public ArrayList<String> getInv() {
        return this.inv;
    }
}
