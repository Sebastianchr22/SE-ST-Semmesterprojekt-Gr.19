package logic;

public class SpilWorldOfZuul
{
    public static void main(String[] args)
    {
        Game game = new Game();
        game.play();
    }

}
