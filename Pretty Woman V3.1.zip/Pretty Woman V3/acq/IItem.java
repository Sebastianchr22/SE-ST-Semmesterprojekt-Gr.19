package acq;

public interface IItem {

    public int getID();

    public String getName();

    public String getDesc();

    public String getCat();

    public int getSize();
}
