package acq;
public interface IPreference {
    public String getPreference();
    public String getName();
    public int getAmount();
}
