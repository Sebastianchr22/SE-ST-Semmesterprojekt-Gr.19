package presentation;

import acq.ILogic;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import acq.IGUI;
import acq.IItem;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.input.MouseEvent;
import logic.LogicFacade;

public class PresentationFacade implements IGUI
{

    private ILogic logic = LogicFacade.getInstance();
    private static IGUI IGUI;
    private Stage mainStage = new Stage();

    /**
     * Injects ILogic
     *
     * @param logic
     */
    @Override
    public void injectLogic(ILogic logic)
    {
        this.logic = logic;
    }

    /**
     * Public accessor method for the instance of the UI.
     *
     * @return IUI
     */
    public static IGUI getInstance()
    {
        return IGUI;
    }

    private Scene scene;

    /**
     * Public accessor method for the instance of the Scene.
     *
     * @return scene
     */
    public Scene getScene()
    {
        return scene;
    }

    /**
     * Boolean accessor method, this boolean is used to stop the game if won = ture
     * 
     *
     * @return getWon
     */
    @Override
    public boolean getGameWon()
    {
        return logic.getWon();
    }

    /**
     * Starts the UI, applying the scene and the main stage.
     *
     * @param mainStage
     * @throws Exception
     */
    @Override
    public void start(Stage mainStage) throws Exception
    {
        IGUI = this;
        Parent root = FXMLLoader.load(getClass().getResource("MainMenu.fxml"));

        scene = new Scene(root);

        setStage(mainStage);
    }

    /**
     * Sets the specifications for the main stage, IE the dimensions.
     *
     * @param stage
     */
    public void setStage(Stage stage)
    {
        mainStage.setMinHeight(600);
        mainStage.setMinWidth(800);
        mainStage.setHeight(600);
        mainStage.setWidth(800);
        mainStage.setResizable(false);
        mainStage.setScene(scene);
        mainStage.show();

        Image icon = new Image(getClass().getResourceAsStream("../FXML/Visuals/Icons/Icon.png"));
        mainStage.setTitle("Pretty Woman - The Game");

        mainStage.getIcons().add(icon);
    }

    private Parent root;

    /**
     * Sets up the window for the new game and sets won to false.
     *
     * @param event
     */
    @Override
    public void newGame(MouseEvent event)
    {
        try
        {
            Parent newgame = FXMLLoader.load(getClass().getResource("Game.fxml"));
            Scene scene = new Scene(newgame);
            Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            appStage.setScene(scene);
            appStage.close();
            appStage.show();
            logic.resetGame();
        }
        catch (IOException ex)
        {
            System.out.println("Error loading");
            Logger.getLogger(PresentationFacade.class.getName()).log(Level.SEVERE, null, ex);
        }
        logic.setWon(false);

    }

    /**
     * Sets up the window for the main menu and sets won to false.
     *
     * @param event
     */
    @Override
    public void mainMenu(MouseEvent event)
    {
        try
        {
            Parent mainmenu = FXMLLoader.load(getClass().getResource("StartScreenFXML.fxml"));
            Scene scene = new Scene(mainmenu);
            Stage appStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            appStage.setScene(scene);
            appStage.close();
            appStage.show();
            logic.resetGame();
        }
        catch (IOException ex)
        {
            System.out.println("Error loading");
            Logger.getLogger(PresentationFacade.class.getName()).log(Level.SEVERE, null, ex);
        }
        logic.setWon(false);

    }

    /**
     * This method creates a new game, and loads the game through the load
     * method on logic, which happens through our logic interface, ILogic.
     *
     * @param event
     */
    @Override
    public void loadGame(MouseEvent event)
    {
        newGame(event);
        logic.load();
    }

    /**
     * Starts the game with mainstage.
     */
    @Override
    public void start()
    {
        try
        {
            start(mainStage);
        }
        catch (Exception ex)
        {
            System.out.println(ex);
            System.out.println("Something went wrong in Initialize");
        }
    }

    /**
     * This method calls the save method on logic through our logic interface,
     * ILogic.
     */
    @Override
    public void save()
    {
        logic.save();
    }

    /**
     * This method calls the load method on logic through our logic interface,
     * ILogic.
     */
    @Override
    public void load()
    {
        logic.load();
    }

    /**
     * This method returns an observable list, containing our saved highscores.
     *
     * @return loadHighScores
     */
    @Override
    public ObservableList loadHighScores()
    {
        return logic.loadHighScore();
    }

    /**
     * Accessor method returns a double, representing the amount of money saved.
     * 
     * @return getMoneySaved
     */
    @Override
    public double getMoney()
    {
        return (logic.getMoneySave() * 100.0) / 100.0;
    }

    /**
     * Accessor method returning an int, representing amount of experience
     * 
     * @return getExperience
     */
    @Override
    public int getExp()
    {
        return logic.getExperience();
    }

    /**
     * Accessor method returning an int, representing the amount of enhancements
     *
     * @return getEnhancements
     */
    @Override
    public int getEnh()
    {
        return logic.getEnhencements();
    }

    /**
     * Accessor method returning an int, representing the amount of moves
     *
     * @return getMoves
     */
    @Override
    public int getMoves()
    {
        return logic.getMoves();
    }

    /**
     * Accessor method returning an int, representing the amount of days left
     *
     * @return getDaysLeft
     */
    @Override
    public int getDaysLeft()
    {
        return logic.getDaysLeft();
    }

    /**
     * Accessor method returning a String, representing the current room
     *
     * @return getCurrentRoom
     */
    @Override
    public String getCurrentRoom()
    {
        return logic.getCurrentRoom();
    }

    /**
     * Accessor method returning a String, representing the capacity
     *
     * @return getCapacity
     */
    @Override
    public String getCapacity()
    {
        return logic.getCapacity();
    }

    /**
     * Accessor method returning an int, representing the current hunger
     *
     * @return getHunger
     */
    @Override
    public int getHunger()
    {
        return logic.getCurrentHunger();
    }

    /**
     * Accessor method returning an String, representing the current hunger out of a maximum of 100
     * 
     * @return getShortHunger
     */
    @Override
    public String getShortHunger()
    {
        return logic.getShortHunger();
    }

    /**
     * Method defined in LogicFacade to buy food, so that you use money to get hunger
     * and then prints texts with the fitting information to what happens
     *
     * @return buyFood
     */
    @Override
    public String buyFood()
    {
        return logic.buyFood();
    }

    /**
     * Method defined in LogicFacade to buy enhancements and prints text with fitting information to what happens
     *
     * @return buyEnhancements
     */
    @Override
    public String buyEnh()
    {
        return logic.buyEnhancements();
    }

    /**
     * Method defined in LogicFacade to show an observable list of items in the gui.
     *
     * @return getInventoryList
     */
    @Override
    public ObservableList<IItem> getInventory()
    {
        return this.logic.getInventoryList();
    }

    /**
     * Method defined in LogicFacade to drop an item from the inventory
     *
     * @param item
     */
    @Override
    public void removeItem(IItem item)
    {
        logic.dropItem(item);
    }

    /**
     * Method takes a command as parameter and gives it to the logic layer, where the method is defined
     *
     * @param command
     * @return processCommand
     */
    @Override
    public String processCommand(String command)
    {
        return logic.processCommand(command);
    }

    /**
     * Mutator method that sets the PrivateRoomCommand variable to s
     *
     * @param s
     */
    @Override
    public void setPrivateRoomCommand(String s)
    {
        logic.setPrivateRoomCommand(s);
    }

    /**
     * Accessor method for getting information about the regular
     *
     * @return getRegularInRoom().info()
     */
    @Override
    public String getRegularInRoomInfo()
    {
        return logic.getRegularInRoom().info();
    }

    /**
     * Boolean method for checking if the manager is in the same room as the player
     *
     * @return managerPlayerSameRoom
     */
    public boolean managerPlayerSameRoom()
    {
        return logic.managerPlayerSameRoom();
    }

    /**
     * Method defined in LogicFacade to take a cut of players money if manager is in the same room
     *
     * @return managerTakesCut
     */
    public String managerTakesCut()
    {
        return logic.managerTakesCut();
    }

    /**
     * Accessor method for getting description of the current room
     *
     * @return
     */
    public String getRoomDescription()
    {
        return logic.getRoomDescription();
    }

    /**
     * Accessor method for getting a boolean value of a private room invite
     *
     * @return getPRoomInvite
     */
    public boolean getPRoomInvite()
    {
        return logic.getPRoomInvite();
    }

    /**
     * Method for removing days left
     */
    public void removeDaysLeft()
    {
        logic.removeDaysLeft();
    }

    /**
     * Accessor method for getting help text fitting for the current room
     *
     * @return getRoomHelpText
     */
    public String getRoomHelpText()
    {
        return logic.getRoomHelpText();
    }
}
