package logic;

import java.util.Set;
import java.util.HashMap;

/**
 * @author Michael Kolling and David J. Barnes
 * @version 2006.03.30
 */
public class Room {

    private String name;
    private String description;
    private String helpText;
    private HashMap<String, Room> exits;

    /**
     * Room constructor
     * 
     * Constructs an object of the type Room with following parameters:
     *
     * @param name
     * @param description
     * @param helpText
     */
    public Room(String name, String description, String helpText) {
        this.name = name;
        this.description = description;
        this.helpText = helpText;
        exits = new HashMap<String, Room>();
    }

    /**
     * Mutator method for setting an exit to another room
     * 
     * Sets an exit to another room with following parameters:
     *
     * @param direction: String value of the neighbor room
     * @param neighbor: Type Room
     */
    public void setExit(String direction, Room neighbor) {
        exits.put(direction, neighbor);
    }

    /**
     * Accessor method for returning a String value of the neighbor room
     * 
     * @return description String
     */
    public String getShortDescription() {
        return description;
    }

    /**
     * Accessor method for returning String of available exits
     * 
     * Uses for each loop to print all the exits from the exit hashmap
     * with additional space between them
     * 
     * @return returnString String
     */
    private String getExitString() {
        String returnString = "Exits:";
        Set<String> keys = exits.keySet();
        for (String exit : keys) {
            returnString += " " + exit;
        }
        return returnString;
    }

    /**
     * Accessor method for getting the Room of a String
     * 
     * @param direction
     * @return exits of type Room
     */
    public Room getExit(String direction) {
        return exits.get(direction);
    }

    /**
     * Accessor method for getting an all caps room name String
     * @return Uppercase name String
     */
    public String getNameBackend() {
        return name.toUpperCase();
    }

    /**
     * Accessor method for getting the helptext attached to the current room
     * @return 
     */
    public String getHelpText() {
        return this.helpText;
    }
}
