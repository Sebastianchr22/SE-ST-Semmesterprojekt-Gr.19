package logic;

import acq.ILogic;
import acq.IRegular;

/**
 *The HotelMotelInvite class is the logic behind a player being invited to either a hotel or motel. 
 * 
 */
public class HotelMotelInvite {

    private ILogic logic;

    /**
     * The method hotel is used when a players has won the game. From the IRegular interface we recieve all the info
     * about the regular who has invited you to hotel. The method first prints a string telling you, you have been 
     * invited to a hotel. A object is then created of winTranslation to check how well you did in the game.
     * then uses the ILogic interface to save your highscore.
     * @param regular 
     * @return val returns a string and from the WinTranslation method you also recieve some info about how well you 
     * did at the game, by printing your win percentage.  
     */
    public String Hotel(IRegular regular) {
        String val = "You have been invited to a Hotel!";
        //Check degree of success in the game:
        //Print win degree:
        WinTranslation trans = new WinTranslation();
        //Set highscore:
        logic.setWon(true);
        return val + "\n" + trans.WinTranslation(logic.getWinPercent(regular));
    }

    /**
     * The motel method works just like the hotel method above. 
     * 
     * @param regular gets all info about a regular from the IRegular interface.
     * @return this returns the val string and info about how well you did at the game.
     */
    public String Motel(IRegular regular) {
        String val = "You have been invited to a Motel.";
        WinTranslation trans = new WinTranslation();
        logic.setWon(true);

        return val + "\n" + trans.WinTranslation(logic.getWinPercent(regular));
    }

    /**
     * The HotelMotelIvite method uses a if-statement that states that, if a regulars name ISNT equal to Jack the bouncer or 
     * Ex-boyfriend daniel and if a regulars wealth is greater then or equal to 1.5m, you will by invited to hotel.
     * But if a regulars wealth is below 1.5m, you will be invited to motel.
     * @param regular 
     * @return returns if you have been invited to either a hotel or motel based on the regular u matched with.
     */
    public String HotelMotelInvite(IRegular regular) {
        logic = LogicFacade.getInstance();
        if (!regular.getName().toUpperCase().equals("JACK THE BOUNCER") && !regular.getName().toUpperCase().equals("EX-BOYFRIEND DANIEL")) {
            if (regular.getWealth() >= 1500000) {
                //If regular is worth more than or equals to 1.5M invite to hotel:
                return Hotel(regular);
            } else {
                //Invite to motel:
                return Motel(regular);
            }
        } else {
            return Hotel(regular);
        }

    }
}