package logic;
public class Item implements acq.IItem {
 
    private int ID;
    private String name;
    private String description;
    private String category;
    private int size;
    
    /**
     * Constructs and initializes an Item with following parameters:
     * @param ID item ID
     * @param name item Name
     * @param desc item Description
     * @param cat item Category
     * @param size item Size
     */
    Item(int ID, String name, String desc, String cat, int size) {
        this.ID = ID;
        this.name = name;
        this.description = desc;
        this.category = cat;
        this.size = size;
    }
    
    /**
     * Accessor method for a string value of the item name and description
     * 
     * @return a string containing item name and item description
     */
    public String getValues() {
        String values = this.name + " - " + this.description;
        return values;
    }
    
    /**
     * Accessor method for an integer value of the item ID
     * 
     * @return an integer of the item ID
     */
    public int getID() {
        return this.ID;
    }
    
    /**
     * Accessor method for a string value of the item Name
     * 
     * @return a string of the item Name
     */
    public String getName() {
        return this.name;
    }
    
    /**
     * Accessor method for a string value of the item Description
     * 
     * @return a string of the item Description
     */
    public String getDesc() {
        return this.description;
    }
    
    /**
     * Accessor method for a string value of the item Category
     * 
     * @return a string of the item Category
     */
    public String getCat() {
        return this.category;
    }
    
    /**
     * Accessor method for a integer value of the item Weight
     * 
     * @return an integer of the item Size
     */
    public int getSize() {
        return this.size;
    }
    
    /**
     * toString method that returns a string representation of an item
     * 
     * @return a string containing item ID, item Name and item Description
     */
    @Override
    public String toString(){
        return this.ID + "." + this.name + " - " + this.description;
    }
}