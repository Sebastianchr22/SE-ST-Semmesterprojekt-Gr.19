package logic;

/**
 *
 * @author Obel
 */
public class Flirt {
    Chance chance = new Chance();
    
    /**
     *The flirt method is only implemented as an easteregg - thereby meaning a little fun thing the programmers
     *leave behind in the finished product, some can be pictures, names or stuff like that, ours is a quick gateway to victory.
     *Basically if this method is called it takes the regular and gives you a 80% chance of matching with him.
     *It only works outside on the "hidden" bouncer.
     * 
     * @param regular
     * @return
     */
    public String Flirt(Regular regular){
        String val = "";
        if(chance.ChanceCalc(80,100)){
            //Successful flirting:
            val = "Your flirting was succesful";
            HotelMotelInvite result = new HotelMotelInvite();
            return val + result.HotelMotelInvite(regular);
        }else{
            val = "It doesn't seem like he heard you.";
        }
        return val;
    }
}