package logic;

import acq.ILogic;

/**
 *
 * The WinTranslation class describes everything that happens when you win the
 * game.
 */

public class WinTranslation {

    private ILogic logic;

    /**
     *
     * This methods will return a string that is used in the winTranslation
     * method. The method's purpose is to give the player feedback about
     * winning.
     *
     * @return this string will be returned if you win.
     */
    public String Won() {
        return "you now have a sugardaddy, and you don't have to strip anymore!";
    }

    /**
     * <p>
     * The method WinTranslation below contains a double parameter called
     * percent. Percent is the amount of points the player has at the end of the
     * game. Based on the value of percent, a string called val, will be
     * displayed how well you did at the game, along with the string from the
     * Won-method.</p>
     *
     * <p>
     * A integer called score is set to be equal to the amount of money,
     * experience, enhancements and days-left the players has. Score is then
     * used to display to the player the highscore to save. Then the method
     * setWon is set to true and the value val which is a string is returned.
     * </p>
     *
     *
     *
     * @param percent the amount of points the player has at the end of a game.
     * @return returns a string of how well you did at the game and a win
     * message!
     */
    public String WinTranslation(double percent) {
        logic = LogicFacade.getInstance();
        String val = "";
        if (percent <= 20.0) {
            val = "You did very poorly, but yet you've made it, " + Won();
        }
        if (percent >= 21 && percent <= 40) {
            val = "You did quite poorly, but yet you've made it, " + Won();
        }
        if (percent >= 41 && percent <= 60) {
            val = "You did alright, and you've made it, " + Won();
        }
        if (percent >= 61 && percent <= 80) {
            val = "You did quite well, and you've made it, " + Won();
        }
        if (percent >= 81 && percent <= 100) {
            val = "You did fantastic, " + Won();
        }
        int score = (int) (logic.getMoneySave() + (logic.getMoneySave() * (1.0 + (percent / 100.0))) * (logic.getExperience() * logic.getEnhencements()) * logic.getDaysLeft());
        System.out.println("Highscore to save: " + score);
        logic.saveHighScore(score);
        logic.setWon(true);
        return val;
    }
}
