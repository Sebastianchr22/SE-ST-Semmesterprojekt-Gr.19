package acq;

import logic.Item;

public interface IListBuilder
{

    /**
     * Adds an item to a list.
     *
     * @param item
     */
    void addToList(Item item);

    /**
     * Removes an item from a list.
     *
     * @param item
     */
    void removeFromList(Item item);
}
